# `events` for Sketch

All the [nodejs events](https://nodejs.org/api/events.html) API is available.
