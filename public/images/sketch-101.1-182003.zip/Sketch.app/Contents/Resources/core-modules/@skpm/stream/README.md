# `stream` for Sketch

All the [nodejs stream](https://nodejs.org/api/stream.html) API is available.
